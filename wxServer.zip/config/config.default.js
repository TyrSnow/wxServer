"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (appInfo) => {
    return {
        keys: `${appInfo.name}_4033365`,
        middleware: []
    };
};
//# sourceMappingURL=config.default.js.map