"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = () => {
    console.log('This is the first run.');
};
//# sourceMappingURL=app.js.map